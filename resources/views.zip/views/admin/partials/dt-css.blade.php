
<link href="{{ asset('lib/highlightjs/github.css')}}" rel="stylesheet">
<link href="{{ asset('lib/datatables/jquery.dataTables.css')}}" rel="stylesheet">
<link href="{{ asset('lib/select2/css/select2.min.css') }}" rel="stylesheet">
