<footer class="foot">
  <div
    class="d-flex align-items-center"
    style=" width: 0; height: 0;opacity: 0"
  >
    <div>
      <p>
        <span>BALANCE: ___ | </span>
        <span>PROFIT/LOSS: ___ | </span>
        <span>EQUITY: ___ | </span>
        <span>MARGIN: ___ | </span>
        <span>FREE MARGIN: ___</span>
      </p>
    </div>
  </div>
</footer>
