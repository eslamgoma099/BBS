

{{--<div class="col-xl-12">--}}
{{--    <div class="card sub-menu">--}}
{{--        <div class="card-body">--}}
{{--            <ul class="d-flex">--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('backend.dashboard') }}" class="nav-link">--}}
{{--                        <i class="mdi mdi-view-dashboard"></i>--}}
{{--                        <span>Dashboard</span>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('backend.account.overview') }}" class="nav-link">--}}
{{--                        <i class="mdi mdi-bullseye"></i>--}}
{{--                        <span>Overview</span>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('backend.deposit.fund') }}" class="nav-link">--}}
{{--                        <i class="mdi mdi-heart"></i>--}}
{{--                        <span>Deposit</span>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--                @if (auth()->user()->can_upgrade)--}}
{{--                    <li class="nav-item">--}}
{{--                        <a href="{{ route('backend.upgrade') }}" class="nav-link">--}}
{{--                            <i class="mdi mdi-arrow-up"></i>--}}
{{--                            <span>Upgrade</span>--}}
{{--                        </a>--}}
{{--                    </li>--}}
{{--                @endif--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('backend.btc.withdrawal') }}?t=available_balance" class="nav-link">--}}
{{--                    <a href="{{ route('backend.withdraw.index') }}" class="nav-link">--}}
{{--                        <i class="mdi mdi-pentagon"></i>--}}
{{--                        <span>Withdraw</span>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--                @if (auth()->user()->can_withdraw)--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('backend.btc.withdrawal') }}?t=account_balance" class="nav-link">--}}
{{--                        <i class="mdi mdi-pentagon"></i>--}}
{{--                        <span>Account Withdrawal</span>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--                @endif--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('backend.trades.index') }}" class="nav-link">--}}
{{--                        <i class="mdi mdi-database"></i>--}}
{{--                        <span>Trades</span>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('backend.account.security') }}" class="nav-link">--}}
{{--                        <i class="mdi mdi-settings"></i>--}}
{{--                        <span>Security Settings</span>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--                <li class="nav-item">--}}
{{--                    <a href="{{ route('backend.transactions') }}" class="nav-link">--}}
{{--                        <i class="mdi mdi-history"></i>--}}
{{--                        <span>Transaction History</span>--}}
{{--                    </a>--}}
{{--                </li>--}}
{{--            </ul>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--</div>--}}
