<?php return array (
  'app' => 
  array (
    'name' => 'investor First Trade',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://127.0.0.1:8000',
    'asset_url' => NULL,
    'timezone' => 'Europe/London',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:I1EV8YbmxitEO00aAHmeb95myPG+oukf4iahw89GZoE=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Watson\\Active\\ActiveServiceProvider',
      23 => 'Tymon\\JWTAuth\\Providers\\LaravelServiceProvider',
      24 => 'Barryvdh\\DomPDF\\ServiceProvider',
      25 => 'App\\Providers\\AppServiceProvider',
      26 => 'App\\Providers\\AuthServiceProvider',
      27 => 'App\\Providers\\EventServiceProvider',
      28 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'JWTAuth' => 'Tymon\\JWTAuth\\Facades\\JWTAuth',
      'JWTFactory' => 'Tymon\\JWTAuth\\Facades\\JWTFactory',
      'PDF' => 'Barryvdh\\DomPDF\\Facade',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'jwt',
        'provider' => 'users',
        'hash' => false,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'authentication-log' => 
  array (
    'notify' => false,
    'older' => 365,
  ),
  'beautymail' => 
  array (
    'colors' => 
    array (
      'highlight' => '#004ca3',
      'button' => '#004cad',
    ),
    'view' => 
    array (
      'senderName' => NULL,
      'reminder' => NULL,
      'unsubscribe' => NULL,
      'address' => NULL,
      'logo' => 
      array (
        'path' => '%PUBLIC%/images/fav.png',
        'width' => '70px',
        'height' => '70px',
      ),
      'twitter' => NULL,
      'facebook' => NULL,
      'flickr' => NULL,
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'null',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
    ),
    'prefix' => 'investor_first_trade_cache',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'countries' => 
  array (
    'AD' => 
    array (
      'name' => 'ANDORRA',
      'code' => '376',
    ),
    'AE' => 
    array (
      'name' => 'UNITED ARAB EMIRATES',
      'code' => '971',
    ),
    'AF' => 
    array (
      'name' => 'AFGHANISTAN',
      'code' => '93',
    ),
    'AG' => 
    array (
      'name' => 'ANTIGUA AND BARBUDA',
      'code' => '1268',
    ),
    'AI' => 
    array (
      'name' => 'ANGUILLA',
      'code' => '1264',
    ),
    'AL' => 
    array (
      'name' => 'ALBANIA',
      'code' => '355',
    ),
    'AM' => 
    array (
      'name' => 'ARMENIA',
      'code' => '374',
    ),
    'AN' => 
    array (
      'name' => 'NETHERLANDS ANTILLES',
      'code' => '599',
    ),
    'AO' => 
    array (
      'name' => 'ANGOLA',
      'code' => '244',
    ),
    'AQ' => 
    array (
      'name' => 'ANTARCTICA',
      'code' => '672',
    ),
    'AR' => 
    array (
      'name' => 'ARGENTINA',
      'code' => '54',
    ),
    'AS' => 
    array (
      'name' => 'AMERICAN SAMOA',
      'code' => '1684',
    ),
    'AT' => 
    array (
      'name' => 'AUSTRIA',
      'code' => '43',
    ),
    'AU' => 
    array (
      'name' => 'AUSTRALIA',
      'code' => '61',
    ),
    'AW' => 
    array (
      'name' => 'ARUBA',
      'code' => '297',
    ),
    'AZ' => 
    array (
      'name' => 'AZERBAIJAN',
      'code' => '994',
    ),
    'BA' => 
    array (
      'name' => 'BOSNIA AND HERZEGOVINA',
      'code' => '387',
    ),
    'BB' => 
    array (
      'name' => 'BARBADOS',
      'code' => '1246',
    ),
    'BD' => 
    array (
      'name' => 'BANGLADESH',
      'code' => '880',
    ),
    'BE' => 
    array (
      'name' => 'BELGIUM',
      'code' => '32',
    ),
    'BF' => 
    array (
      'name' => 'BURKINA FASO',
      'code' => '226',
    ),
    'BG' => 
    array (
      'name' => 'BULGARIA',
      'code' => '359',
    ),
    'BH' => 
    array (
      'name' => 'BAHRAIN',
      'code' => '973',
    ),
    'BI' => 
    array (
      'name' => 'BURUNDI',
      'code' => '257',
    ),
    'BJ' => 
    array (
      'name' => 'BENIN',
      'code' => '229',
    ),
    'BL' => 
    array (
      'name' => 'SAINT BARTHELEMY',
      'code' => '590',
    ),
    'BM' => 
    array (
      'name' => 'BERMUDA',
      'code' => '1441',
    ),
    'BN' => 
    array (
      'name' => 'BRUNEI DARUSSALAM',
      'code' => '673',
    ),
    'BO' => 
    array (
      'name' => 'BOLIVIA',
      'code' => '591',
    ),
    'BR' => 
    array (
      'name' => 'BRAZIL',
      'code' => '55',
    ),
    'BS' => 
    array (
      'name' => 'BAHAMAS',
      'code' => '1242',
    ),
    'BT' => 
    array (
      'name' => 'BHUTAN',
      'code' => '975',
    ),
    'BW' => 
    array (
      'name' => 'BOTSWANA',
      'code' => '267',
    ),
    'BY' => 
    array (
      'name' => 'BELARUS',
      'code' => '375',
    ),
    'BZ' => 
    array (
      'name' => 'BELIZE',
      'code' => '501',
    ),
    'CA' => 
    array (
      'name' => 'CANADA',
      'code' => '1',
    ),
    'CC' => 
    array (
      'name' => 'COCOS (KEELING) ISLANDS',
      'code' => '61',
    ),
    'CD' => 
    array (
      'name' => 'CONGO, THE DEMOCRATIC REPUBLIC OF THE',
      'code' => '243',
    ),
    'CF' => 
    array (
      'name' => 'CENTRAL AFRICAN REPUBLIC',
      'code' => '236',
    ),
    'CG' => 
    array (
      'name' => 'CONGO',
      'code' => '242',
    ),
    'CH' => 
    array (
      'name' => 'SWITZERLAND',
      'code' => '41',
    ),
    'CI' => 
    array (
      'name' => 'COTE D IVOIRE',
      'code' => '225',
    ),
    'CK' => 
    array (
      'name' => 'COOK ISLANDS',
      'code' => '682',
    ),
    'CL' => 
    array (
      'name' => 'CHILE',
      'code' => '56',
    ),
    'CM' => 
    array (
      'name' => 'CAMEROON',
      'code' => '237',
    ),
    'CN' => 
    array (
      'name' => 'CHINA',
      'code' => '86',
    ),
    'CO' => 
    array (
      'name' => 'COLOMBIA',
      'code' => '57',
    ),
    'CR' => 
    array (
      'name' => 'COSTA RICA',
      'code' => '506',
    ),
    'CU' => 
    array (
      'name' => 'CUBA',
      'code' => '53',
    ),
    'CV' => 
    array (
      'name' => 'CAPE VERDE',
      'code' => '238',
    ),
    'CX' => 
    array (
      'name' => 'CHRISTMAS ISLAND',
      'code' => '61',
    ),
    'CY' => 
    array (
      'name' => 'CYPRUS',
      'code' => '357',
    ),
    'CZ' => 
    array (
      'name' => 'CZECH REPUBLIC',
      'code' => '420',
    ),
    'DE' => 
    array (
      'name' => 'GERMANY',
      'code' => '49',
    ),
    'DJ' => 
    array (
      'name' => 'DJIBOUTI',
      'code' => '253',
    ),
    'DK' => 
    array (
      'name' => 'DENMARK',
      'code' => '45',
    ),
    'DM' => 
    array (
      'name' => 'DOMINICA',
      'code' => '1767',
    ),
    'DO' => 
    array (
      'name' => 'DOMINICAN REPUBLIC',
      'code' => '1809',
    ),
    'DZ' => 
    array (
      'name' => 'ALGERIA',
      'code' => '213',
    ),
    'EC' => 
    array (
      'name' => 'ECUADOR',
      'code' => '593',
    ),
    'EE' => 
    array (
      'name' => 'ESTONIA',
      'code' => '372',
    ),
    'EG' => 
    array (
      'name' => 'EGYPT',
      'code' => '20',
    ),
    'ER' => 
    array (
      'name' => 'ERITREA',
      'code' => '291',
    ),
    'ES' => 
    array (
      'name' => 'SPAIN',
      'code' => '34',
    ),
    'ET' => 
    array (
      'name' => 'ETHIOPIA',
      'code' => '251',
    ),
    'FI' => 
    array (
      'name' => 'FINLAND',
      'code' => '358',
    ),
    'FJ' => 
    array (
      'name' => 'FIJI',
      'code' => '679',
    ),
    'FK' => 
    array (
      'name' => 'FALKLAND ISLANDS (MALVINAS)',
      'code' => '500',
    ),
    'FM' => 
    array (
      'name' => 'MICRONESIA, FEDERATED STATES OF',
      'code' => '691',
    ),
    'FO' => 
    array (
      'name' => 'FAROE ISLANDS',
      'code' => '298',
    ),
    'FR' => 
    array (
      'name' => 'FRANCE',
      'code' => '33',
    ),
    'GA' => 
    array (
      'name' => 'GABON',
      'code' => '241',
    ),
    'GB' => 
    array (
      'name' => 'UNITED KINGDOM',
      'code' => '44',
    ),
    'GD' => 
    array (
      'name' => 'GRENADA',
      'code' => '1473',
    ),
    'GE' => 
    array (
      'name' => 'GEORGIA',
      'code' => '995',
    ),
    'GH' => 
    array (
      'name' => 'GHANA',
      'code' => '233',
    ),
    'GI' => 
    array (
      'name' => 'GIBRALTAR',
      'code' => '350',
    ),
    'GL' => 
    array (
      'name' => 'GREENLAND',
      'code' => '299',
    ),
    'GM' => 
    array (
      'name' => 'GAMBIA',
      'code' => '220',
    ),
    'GN' => 
    array (
      'name' => 'GUINEA',
      'code' => '224',
    ),
    'GQ' => 
    array (
      'name' => 'EQUATORIAL GUINEA',
      'code' => '240',
    ),
    'GR' => 
    array (
      'name' => 'GREECE',
      'code' => '30',
    ),
    'GT' => 
    array (
      'name' => 'GUATEMALA',
      'code' => '502',
    ),
    'GU' => 
    array (
      'name' => 'GUAM',
      'code' => '1671',
    ),
    'GW' => 
    array (
      'name' => 'GUINEA-BISSAU',
      'code' => '245',
    ),
    'GY' => 
    array (
      'name' => 'GUYANA',
      'code' => '592',
    ),
    'HK' => 
    array (
      'name' => 'HONG KONG',
      'code' => '852',
    ),
    'HN' => 
    array (
      'name' => 'HONDURAS',
      'code' => '504',
    ),
    'HR' => 
    array (
      'name' => 'CROATIA',
      'code' => '385',
    ),
    'HT' => 
    array (
      'name' => 'HAITI',
      'code' => '509',
    ),
    'HU' => 
    array (
      'name' => 'HUNGARY',
      'code' => '36',
    ),
    'ID' => 
    array (
      'name' => 'INDONESIA',
      'code' => '62',
    ),
    'IE' => 
    array (
      'name' => 'IRELAND',
      'code' => '353',
    ),
    'IL' => 
    array (
      'name' => 'ISRAEL',
      'code' => '972',
    ),
    'IM' => 
    array (
      'name' => 'ISLE OF MAN',
      'code' => '44',
    ),
    'IN' => 
    array (
      'name' => 'INDIA',
      'code' => '91',
    ),
    'IQ' => 
    array (
      'name' => 'IRAQ',
      'code' => '964',
    ),
    'IR' => 
    array (
      'name' => 'IRAN, ISLAMIC REPUBLIC OF',
      'code' => '98',
    ),
    'IS' => 
    array (
      'name' => 'ICELAND',
      'code' => '354',
    ),
    'IT' => 
    array (
      'name' => 'ITALY',
      'code' => '39',
    ),
    'JM' => 
    array (
      'name' => 'JAMAICA',
      'code' => '1876',
    ),
    'JO' => 
    array (
      'name' => 'JORDAN',
      'code' => '962',
    ),
    'JP' => 
    array (
      'name' => 'JAPAN',
      'code' => '81',
    ),
    'KE' => 
    array (
      'name' => 'KENYA',
      'code' => '254',
    ),
    'KG' => 
    array (
      'name' => 'KYRGYZSTAN',
      'code' => '996',
    ),
    'KH' => 
    array (
      'name' => 'CAMBODIA',
      'code' => '855',
    ),
    'KI' => 
    array (
      'name' => 'KIRIBATI',
      'code' => '686',
    ),
    'KM' => 
    array (
      'name' => 'COMOROS',
      'code' => '269',
    ),
    'KN' => 
    array (
      'name' => 'SAINT KITTS AND NEVIS',
      'code' => '1869',
    ),
    'KP' => 
    array (
      'name' => 'KOREA DEMOCRATIC PEOPLES REPUBLIC OF',
      'code' => '850',
    ),
    'KR' => 
    array (
      'name' => 'KOREA REPUBLIC OF',
      'code' => '82',
    ),
    'KW' => 
    array (
      'name' => 'KUWAIT',
      'code' => '965',
    ),
    'KY' => 
    array (
      'name' => 'CAYMAN ISLANDS',
      'code' => '1345',
    ),
    'KZ' => 
    array (
      'name' => 'KAZAKSTAN',
      'code' => '7',
    ),
    'LA' => 
    array (
      'name' => 'LAO PEOPLES DEMOCRATIC REPUBLIC',
      'code' => '856',
    ),
    'LB' => 
    array (
      'name' => 'LEBANON',
      'code' => '961',
    ),
    'LC' => 
    array (
      'name' => 'SAINT LUCIA',
      'code' => '1758',
    ),
    'LI' => 
    array (
      'name' => 'LIECHTENSTEIN',
      'code' => '423',
    ),
    'LK' => 
    array (
      'name' => 'SRI LANKA',
      'code' => '94',
    ),
    'LR' => 
    array (
      'name' => 'LIBERIA',
      'code' => '231',
    ),
    'LS' => 
    array (
      'name' => 'LESOTHO',
      'code' => '266',
    ),
    'LT' => 
    array (
      'name' => 'LITHUANIA',
      'code' => '370',
    ),
    'LU' => 
    array (
      'name' => 'LUXEMBOURG',
      'code' => '352',
    ),
    'LV' => 
    array (
      'name' => 'LATVIA',
      'code' => '371',
    ),
    'LY' => 
    array (
      'name' => 'LIBYAN ARAB JAMAHIRIYA',
      'code' => '218',
    ),
    'MA' => 
    array (
      'name' => 'MOROCCO',
      'code' => '212',
    ),
    'MC' => 
    array (
      'name' => 'MONACO',
      'code' => '377',
    ),
    'MD' => 
    array (
      'name' => 'MOLDOVA, REPUBLIC OF',
      'code' => '373',
    ),
    'ME' => 
    array (
      'name' => 'MONTENEGRO',
      'code' => '382',
    ),
    'MF' => 
    array (
      'name' => 'SAINT MARTIN',
      'code' => '1599',
    ),
    'MG' => 
    array (
      'name' => 'MADAGASCAR',
      'code' => '261',
    ),
    'MH' => 
    array (
      'name' => 'MARSHALL ISLANDS',
      'code' => '692',
    ),
    'MK' => 
    array (
      'name' => 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF',
      'code' => '389',
    ),
    'ML' => 
    array (
      'name' => 'MALI',
      'code' => '223',
    ),
    'MM' => 
    array (
      'name' => 'MYANMAR',
      'code' => '95',
    ),
    'MN' => 
    array (
      'name' => 'MONGOLIA',
      'code' => '976',
    ),
    'MO' => 
    array (
      'name' => 'MACAU',
      'code' => '853',
    ),
    'MP' => 
    array (
      'name' => 'NORTHERN MARIANA ISLANDS',
      'code' => '1670',
    ),
    'MR' => 
    array (
      'name' => 'MAURITANIA',
      'code' => '222',
    ),
    'MS' => 
    array (
      'name' => 'MONTSERRAT',
      'code' => '1664',
    ),
    'MT' => 
    array (
      'name' => 'MALTA',
      'code' => '356',
    ),
    'MU' => 
    array (
      'name' => 'MAURITIUS',
      'code' => '230',
    ),
    'MV' => 
    array (
      'name' => 'MALDIVES',
      'code' => '960',
    ),
    'MW' => 
    array (
      'name' => 'MALAWI',
      'code' => '265',
    ),
    'MX' => 
    array (
      'name' => 'MEXICO',
      'code' => '52',
    ),
    'MY' => 
    array (
      'name' => 'MALAYSIA',
      'code' => '60',
    ),
    'MZ' => 
    array (
      'name' => 'MOZAMBIQUE',
      'code' => '258',
    ),
    'NA' => 
    array (
      'name' => 'NAMIBIA',
      'code' => '264',
    ),
    'NC' => 
    array (
      'name' => 'NEW CALEDONIA',
      'code' => '687',
    ),
    'NE' => 
    array (
      'name' => 'NIGER',
      'code' => '227',
    ),
    'NG' => 
    array (
      'name' => 'NIGERIA',
      'code' => '234',
    ),
    'NI' => 
    array (
      'name' => 'NICARAGUA',
      'code' => '505',
    ),
    'NL' => 
    array (
      'name' => 'NETHERLANDS',
      'code' => '31',
    ),
    'NO' => 
    array (
      'name' => 'NORWAY',
      'code' => '47',
    ),
    'NP' => 
    array (
      'name' => 'NEPAL',
      'code' => '977',
    ),
    'NR' => 
    array (
      'name' => 'NAURU',
      'code' => '674',
    ),
    'NU' => 
    array (
      'name' => 'NIUE',
      'code' => '683',
    ),
    'NZ' => 
    array (
      'name' => 'NEW ZEALAND',
      'code' => '64',
    ),
    'OM' => 
    array (
      'name' => 'OMAN',
      'code' => '968',
    ),
    'PA' => 
    array (
      'name' => 'PANAMA',
      'code' => '507',
    ),
    'PE' => 
    array (
      'name' => 'PERU',
      'code' => '51',
    ),
    'PF' => 
    array (
      'name' => 'FRENCH POLYNESIA',
      'code' => '689',
    ),
    'PG' => 
    array (
      'name' => 'PAPUA NEW GUINEA',
      'code' => '675',
    ),
    'PH' => 
    array (
      'name' => 'PHILIPPINES',
      'code' => '63',
    ),
    'PK' => 
    array (
      'name' => 'PAKISTAN',
      'code' => '92',
    ),
    'PL' => 
    array (
      'name' => 'POLAND',
      'code' => '48',
    ),
    'PM' => 
    array (
      'name' => 'SAINT PIERRE AND MIQUELON',
      'code' => '508',
    ),
    'PN' => 
    array (
      'name' => 'PITCAIRN',
      'code' => '870',
    ),
    'PR' => 
    array (
      'name' => 'PUERTO RICO',
      'code' => '1',
    ),
    'PT' => 
    array (
      'name' => 'PORTUGAL',
      'code' => '351',
    ),
    'PW' => 
    array (
      'name' => 'PALAU',
      'code' => '680',
    ),
    'PY' => 
    array (
      'name' => 'PARAGUAY',
      'code' => '595',
    ),
    'QA' => 
    array (
      'name' => 'QATAR',
      'code' => '974',
    ),
    'RO' => 
    array (
      'name' => 'ROMANIA',
      'code' => '40',
    ),
    'RS' => 
    array (
      'name' => 'SERBIA',
      'code' => '381',
    ),
    'RU' => 
    array (
      'name' => 'RUSSIAN FEDERATION',
      'code' => '7',
    ),
    'RW' => 
    array (
      'name' => 'RWANDA',
      'code' => '250',
    ),
    'SA' => 
    array (
      'name' => 'SAUDI ARABIA',
      'code' => '966',
    ),
    'SB' => 
    array (
      'name' => 'SOLOMON ISLANDS',
      'code' => '677',
    ),
    'SC' => 
    array (
      'name' => 'SEYCHELLES',
      'code' => '248',
    ),
    'SD' => 
    array (
      'name' => 'SUDAN',
      'code' => '249',
    ),
    'SE' => 
    array (
      'name' => 'SWEDEN',
      'code' => '46',
    ),
    'SG' => 
    array (
      'name' => 'SINGAPORE',
      'code' => '65',
    ),
    'SH' => 
    array (
      'name' => 'SAINT HELENA',
      'code' => '290',
    ),
    'SI' => 
    array (
      'name' => 'SLOVENIA',
      'code' => '386',
    ),
    'SK' => 
    array (
      'name' => 'SLOVAKIA',
      'code' => '421',
    ),
    'SL' => 
    array (
      'name' => 'SIERRA LEONE',
      'code' => '232',
    ),
    'SM' => 
    array (
      'name' => 'SAN MARINO',
      'code' => '378',
    ),
    'SN' => 
    array (
      'name' => 'SENEGAL',
      'code' => '221',
    ),
    'SO' => 
    array (
      'name' => 'SOMALIA',
      'code' => '252',
    ),
    'SR' => 
    array (
      'name' => 'SURINAME',
      'code' => '597',
    ),
    'ST' => 
    array (
      'name' => 'SAO TOME AND PRINCIPE',
      'code' => '239',
    ),
    'SV' => 
    array (
      'name' => 'EL SALVADOR',
      'code' => '503',
    ),
    'SY' => 
    array (
      'name' => 'SYRIAN ARAB REPUBLIC',
      'code' => '963',
    ),
    'SZ' => 
    array (
      'name' => 'SWAZILAND',
      'code' => '268',
    ),
    'TC' => 
    array (
      'name' => 'TURKS AND CAICOS ISLANDS',
      'code' => '1649',
    ),
    'TD' => 
    array (
      'name' => 'CHAD',
      'code' => '235',
    ),
    'TG' => 
    array (
      'name' => 'TOGO',
      'code' => '228',
    ),
    'TH' => 
    array (
      'name' => 'THAILAND',
      'code' => '66',
    ),
    'TJ' => 
    array (
      'name' => 'TAJIKISTAN',
      'code' => '992',
    ),
    'TK' => 
    array (
      'name' => 'TOKELAU',
      'code' => '690',
    ),
    'TL' => 
    array (
      'name' => 'TIMOR-LESTE',
      'code' => '670',
    ),
    'TM' => 
    array (
      'name' => 'TURKMENISTAN',
      'code' => '993',
    ),
    'TN' => 
    array (
      'name' => 'TUNISIA',
      'code' => '216',
    ),
    'TO' => 
    array (
      'name' => 'TONGA',
      'code' => '676',
    ),
    'TR' => 
    array (
      'name' => 'TURKEY',
      'code' => '90',
    ),
    'TT' => 
    array (
      'name' => 'TRINIDAD AND TOBAGO',
      'code' => '1868',
    ),
    'TV' => 
    array (
      'name' => 'TUVALU',
      'code' => '688',
    ),
    'TW' => 
    array (
      'name' => 'TAIWAN, PROVINCE OF CHINA',
      'code' => '886',
    ),
    'TZ' => 
    array (
      'name' => 'TANZANIA, UNITED REPUBLIC OF',
      'code' => '255',
    ),
    'UA' => 
    array (
      'name' => 'UKRAINE',
      'code' => '380',
    ),
    'UG' => 
    array (
      'name' => 'UGANDA',
      'code' => '256',
    ),
    'US' => 
    array (
      'name' => 'UNITED STATES',
      'code' => '1',
    ),
    'UY' => 
    array (
      'name' => 'URUGUAY',
      'code' => '598',
    ),
    'UZ' => 
    array (
      'name' => 'UZBEKISTAN',
      'code' => '998',
    ),
    'VA' => 
    array (
      'name' => 'HOLY SEE (VATICAN CITY STATE)',
      'code' => '39',
    ),
    'VC' => 
    array (
      'name' => 'SAINT VINCENT AND THE GRENADINES',
      'code' => '1784',
    ),
    'VE' => 
    array (
      'name' => 'VENEZUELA',
      'code' => '58',
    ),
    'VG' => 
    array (
      'name' => 'VIRGIN ISLANDS, BRITISH',
      'code' => '1284',
    ),
    'VI' => 
    array (
      'name' => 'VIRGIN ISLANDS, U.S.',
      'code' => '1340',
    ),
    'VN' => 
    array (
      'name' => 'VIET NAM',
      'code' => '84',
    ),
    'VU' => 
    array (
      'name' => 'VANUATU',
      'code' => '678',
    ),
    'WF' => 
    array (
      'name' => 'WALLIS AND FUTUNA',
      'code' => '681',
    ),
    'WS' => 
    array (
      'name' => 'SAMOA',
      'code' => '685',
    ),
    'XK' => 
    array (
      'name' => 'KOSOVO',
      'code' => '381',
    ),
    'YE' => 
    array (
      'name' => 'YEMEN',
      'code' => '967',
    ),
    'YT' => 
    array (
      'name' => 'MAYOTTE',
      'code' => '262',
    ),
    'ZA' => 
    array (
      'name' => 'SOUTH AFRICA',
      'code' => '27',
    ),
    'ZM' => 
    array (
      'name' => 'ZAMBIA',
      'code' => '260',
    ),
    'ZW' => 
    array (
      'name' => 'ZIMBABWE',
      'code' => '263',
    ),
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\database\\db.sqlite',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'platform',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => 'InnoDB',
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'platform',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'platform',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'investor_first_trade_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'default-model-sorting' => 
  array (
    'order_by' => 'desc',
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'public_path' => NULL,
    'convert_entities' => true,
    'options' => 
    array (
      'font_dir' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\fonts',
      'font_cache' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\fonts',
      'temp_dir' => 'C:\\Users\\ADMINI~1\\AppData\\Local\\Temp\\2',
      'chroot' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates',
      'allowed_protocols' => 
      array (
        'file://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'http://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'https://' => 
        array (
          'rules' => 
          array (
          ),
        ),
      ),
      'log_output_file' => NULL,
      'enable_font_subsetting' => false,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_paper_orientation' => 'portrait',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => true,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => true,
    ),
  ),
  'eod' => 
  array (
    'api_token' => 'put your token here',
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'strict_null_comparison' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'ignore_empty' => false,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'UTF-8',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'cache' => 
    array (
      'driver' => 'memory',
      'batch' => 
      array (
        'memory_limit' => 60000,
      ),
      'illuminate' => 
      array (
        'store' => NULL,
      ),
    ),
    'transactions' => 
    array (
      'handler' => 'db',
    ),
    'temporary_files' => 
    array (
      'local_path' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\framework/cache/laravel-excel',
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
      'force_resync_remote' => NULL,
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\public\\/',
        'url' => 'http://127.0.0.1:8000',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
      ),
    ),
    'links' => 
    array (
      'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\public\\storage' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\app/public',
    ),
  ),
  'google2fa' => 
  array (
    'enabled' => true,
    'lifetime' => 0,
    'keep_alive' => true,
    'auth' => 'auth',
    'guard' => '',
    'session_var' => 'google2fa',
    'otp_input' => 'one_time_password',
    'window' => 1,
    'forbid_old_passwords' => false,
    'otp_secret_column' => 'google2fa_secret',
    'view' => 'google2fa.index',
    'error_messages' => 
    array (
      'wrong_otp' => 'The \'One Time Password\' typed was wrong.',
      'cannot_be_empty' => 'One Time Password cannot be empty.',
      'unknown' => 'An unknown error has occurred. Please try again.',
    ),
    'throw_exceptions' => true,
    'qrcode_image_backend' => 'svg',
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'impersonate' => 
  array (
    'enabled' => false,
    'except' => 
    array (
      0 => 'telescope*',
      1 => 'horizon*',
    ),
    'position' => 'right',
    'model' => 'App\\Models\\User',
    'field' => 
    array (
      'display' => 'name',
      'search_keys' => 
      array (
        0 => 'name',
        1 => 'email',
      ),
    ),
    'delay' => 250,
    'limit' => 5,
  ),
  'jwt' => 
  array (
    'secret' => NULL,
    'keys' => 
    array (
      'public' => NULL,
      'private' => NULL,
      'passphrase' => NULL,
    ),
    'ttl' => 60,
    'refresh_ttl' => 20160,
    'algo' => 'HS256',
    'required_claims' => 
    array (
      0 => 'iss',
      1 => 'iat',
      2 => 'exp',
      3 => 'nbf',
      4 => 'sub',
      5 => 'jti',
    ),
    'persistent_claims' => 
    array (
    ),
    'lock_subject' => true,
    'leeway' => 0,
    'blacklist_enabled' => true,
    'blacklist_grace_period' => 0,
    'decrypt_cookies' => false,
    'providers' => 
    array (
      'jwt' => 'Tymon\\JWTAuth\\Providers\\JWT\\Lcobucci',
      'auth' => 'Tymon\\JWTAuth\\Providers\\Auth\\Illuminate',
      'storage' => 'Tymon\\JWTAuth\\Providers\\Storage\\Illuminate',
    ),
  ),
  'laratrust' => 
  array (
    'use_morph_map' => false,
    'checker' => 'default',
    'cache' => 
    array (
      'enabled' => true,
      'expiration_time' => 3600,
    ),
    'user_models' => 
    array (
      'users' => 'App\\Models\\User',
    ),
    'models' => 
    array (
      'role' => 'App\\Models\\Role',
      'permission' => 'App\\Models\\Permission',
      'team' => 'App\\Models\\Team',
    ),
    'tables' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'teams' => 'teams',
      'role_user' => 'role_user',
      'permission_user' => 'permission_user',
      'permission_role' => 'permission_role',
    ),
    'foreign_keys' => 
    array (
      'user' => 'user_id',
      'role' => 'role_id',
      'permission' => 'permission_id',
      'team' => 'team_id',
    ),
    'middleware' => 
    array (
      'register' => true,
      'handling' => 'abort',
      'handlers' => 
      array (
        'abort' => 
        array (
          'code' => 403,
          'message' => 'User does not have any of the necessary access rights.',
        ),
        'redirect' => 
        array (
          'url' => '/home',
          'message' => 
          array (
            'key' => 'error',
            'content' => '',
          ),
        ),
      ),
    ),
    'teams' => 
    array (
      'enabled' => false,
      'strict_check' => false,
    ),
    'magic_is_able_to_method_case' => 'kebab_case',
    'permissions_as_gates' => false,
    'panel' => 
    array (
      'register' => false,
      'path' => 'laratrust',
      'go_back_route' => '/',
      'middleware' => 
      array (
        0 => 'web',
      ),
      'assign_permissions_to_user' => true,
      'roles_restrictions' => 
      array (
        'not_removable' => 
        array (
        ),
        'not_editable' => 
        array (
        ),
        'not_deletable' => 
        array (
        ),
      ),
    ),
  ),
  'laratrust_seeder' => 
  array (
    'create_users' => true,
    'truncate_tables' => true,
    'roles_structure' => 
    array (
      'superadmin' => 
      array (
        'users' => 'c,r,u,d',
        'payments' => 'c,r,u,d',
        'profile' => 'r,u',
      ),
      'admin' => 
      array (
        'users' => 'c,r,u,d',
        'profile' => 'r,u',
      ),
      'user' => 
      array (
        'profile' => 'r,u',
      ),
    ),
    'permissions_map' => 
    array (
      'c' => 'create',
      'r' => 'read',
      'u' => 'update',
      'd' => 'delete',
    ),
  ),
  'lfm' => 
  array (
    'use_package_routes' => true,
    'allow_private_folder' => true,
    'private_folder_name' => 'UniSharp\\LaravelFilemanager\\Handlers\\ConfigHandler',
    'allow_shared_folder' => true,
    'shared_folder_name' => 'shares',
    'folder_categories' => 
    array (
      'file' => 
      array (
        'folder_name' => 'files',
        'startup_view' => 'list',
        'max_size' => 50000,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
          4 => 'image/svg+xml',
          5 => 'application/pdf',
          6 => 'text/plain',
        ),
      ),
      'image' => 
      array (
        'folder_name' => 'photos',
        'startup_view' => 'grid',
        'max_size' => 5000,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
          4 => 'image/svg+xml',
        ),
      ),
    ),
    'paginator' => 
    array (
      'perPage' => 30,
    ),
    'disk' => 'public',
    'rename_file' => true,
    'rename_duplicates' => false,
    'alphanumeric_filename' => false,
    'alphanumeric_directory' => false,
    'should_validate_size' => false,
    'should_validate_mime' => false,
    'over_write_on_duplicate' => false,
    'should_create_thumbnails' => true,
    'thumb_folder_name' => 'thumbs',
    'raster_mimetypes' => 
    array (
      0 => 'image/jpeg',
      1 => 'image/pjpeg',
      2 => 'image/png',
    ),
    'thumb_img_width' => 200,
    'thumb_img_height' => 200,
    'file_type_array' => 
    array (
      'pdf' => 'Adobe Acrobat',
      'doc' => 'Microsoft Word',
      'docx' => 'Microsoft Word',
      'xls' => 'Microsoft Excel',
      'xlsx' => 'Microsoft Excel',
      'zip' => 'Archive',
      'gif' => 'GIF Image',
      'jpg' => 'JPEG Image',
      'jpeg' => 'JPEG Image',
      'png' => 'PNG Image',
      'ppt' => 'Microsoft PowerPoint',
      'pptx' => 'Microsoft PowerPoint',
    ),
    'php_ini_overrides' => 
    array (
      'memory_limit' => '256M',
    ),
  ),
  'logging' => 
  array (
    'default' => 'STACK',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'host' => 'smtp.titan.email',
        'port' => '465',
        'encryption' => 'ssl',
        'username' => 'trade@web-terminal.online',
        'password' => 'q4BCBFLr3S',
        'timeout' => NULL,
        'auth_mode' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
    ),
    'from' => 
    array (
      'address' => 'trade@web-terminal.online',
      'name' => 'investor First Trade',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'suffix' => NULL,
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'scribe' => 
  array (
    'theme' => 'default',
    'title' => 'Webtrader plus',
    'description' => '',
    'base_url' => 'webtrader.plus',
    'routes' => 
    array (
      0 => 
      array (
        'match' => 
        array (
          'prefixes' => 
          array (
            0 => 'api/v1/*',
          ),
          'domains' => 
          array (
            0 => '*',
          ),
          'versions' => 
          array (
            0 => 'v1',
          ),
        ),
        'include' => 
        array (
        ),
        'exclude' => 
        array (
        ),
        'apply' => 
        array (
          'headers' => 
          array (
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
          ),
          'response_calls' => 
          array (
            'methods' => 
            array (
              0 => 'GET',
            ),
            'config' => 
            array (
              'app.env' => 'documentation',
            ),
            'queryParams' => 
            array (
            ),
            'bodyParams' => 
            array (
            ),
            'fileParams' => 
            array (
            ),
            'cookies' => 
            array (
            ),
          ),
        ),
      ),
    ),
    'type' => 'static',
    'static' => 
    array (
      'output_path' => 'public/docs',
    ),
    'laravel' => 
    array (
      'add_routes' => true,
      'docs_url' => '/docs',
      'middleware' => 
      array (
      ),
    ),
    'try_it_out' => 
    array (
      'enabled' => true,
      'base_url' => 'webtrader.plus',
      'use_csrf' => false,
      'csrf_url' => '/sanctum/csrf-cookie',
    ),
    'auth' => 
    array (
      'enabled' => false,
      'default' => false,
      'in' => 'bearer',
      'name' => 'key',
      'use_value' => NULL,
      'placeholder' => '{YOUR_AUTH_KEY}',
      'extra_info' => 'You can retrieve your token by visiting your dashboard and clicking <b>Generate API token</b>.',
    ),
    'intro_text' => 'This documentation aims to provide all the information you need to work with webtrader api.

<aside>As you scroll, you\'ll see code examples for working with the API in different programming languages in the dark area to the right (or as part of the content on mobile).
You can switch the language used with the tabs at the top right (or from the nav menu at the top left on mobile).</aside>',
    'example_languages' => 
    array (
      0 => 'bash',
      1 => 'javascript',
    ),
    'postman' => 
    array (
      'enabled' => true,
      'overrides' => 
      array (
      ),
    ),
    'openapi' => 
    array (
      'enabled' => false,
      'overrides' => 
      array (
      ),
    ),
    'default_group' => 'Endpoints',
    'logo' => false,
    'faker_seed' => NULL,
    'strategies' => 
    array (
      'metadata' => 
      array (
        0 => 'Knuckles\\Scribe\\Extracting\\Strategies\\Metadata\\GetFromDocBlocks',
      ),
      'urlParameters' => 
      array (
        0 => 'Knuckles\\Scribe\\Extracting\\Strategies\\UrlParameters\\GetFromLaravelAPI',
        1 => 'Knuckles\\Scribe\\Extracting\\Strategies\\UrlParameters\\GetFromLumenAPI',
        2 => 'Knuckles\\Scribe\\Extracting\\Strategies\\UrlParameters\\GetFromUrlParamTag',
      ),
      'queryParameters' => 
      array (
        0 => 'Knuckles\\Scribe\\Extracting\\Strategies\\QueryParameters\\GetFromFormRequest',
        1 => 'Knuckles\\Scribe\\Extracting\\Strategies\\QueryParameters\\GetFromInlineValidator',
        2 => 'Knuckles\\Scribe\\Extracting\\Strategies\\QueryParameters\\GetFromQueryParamTag',
      ),
      'headers' => 
      array (
        0 => 'Knuckles\\Scribe\\Extracting\\Strategies\\Headers\\GetFromRouteRules',
        1 => 'Knuckles\\Scribe\\Extracting\\Strategies\\Headers\\GetFromHeaderTag',
      ),
      'bodyParameters' => 
      array (
        0 => 'Knuckles\\Scribe\\Extracting\\Strategies\\BodyParameters\\GetFromFormRequest',
        1 => 'Knuckles\\Scribe\\Extracting\\Strategies\\BodyParameters\\GetFromInlineValidator',
        2 => 'Knuckles\\Scribe\\Extracting\\Strategies\\BodyParameters\\GetFromBodyParamTag',
      ),
      'responses' => 
      array (
        0 => 'Knuckles\\Scribe\\Extracting\\Strategies\\Responses\\UseTransformerTags',
        1 => 'Knuckles\\Scribe\\Extracting\\Strategies\\Responses\\UseApiResourceTags',
        2 => 'Knuckles\\Scribe\\Extracting\\Strategies\\Responses\\UseResponseTag',
        3 => 'Knuckles\\Scribe\\Extracting\\Strategies\\Responses\\UseResponseFileTag',
        4 => 'Knuckles\\Scribe\\Extracting\\Strategies\\Responses\\ResponseCalls',
      ),
      'responseFields' => 
      array (
        0 => 'Knuckles\\Scribe\\Extracting\\Strategies\\ResponseFields\\GetFromResponseFieldTag',
      ),
    ),
    'fractal' => 
    array (
      'serializer' => NULL,
    ),
    'routeMatcher' => 'Knuckles\\Scribe\\Matching\\RouteMatcher',
    'database_connections_to_transact' => 
    array (
      0 => 'mysql',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'investor_first_trade_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'setting' => 
  array (
    'auto_save' => false,
    'cache' => 
    array (
      'enabled' => false,
      'key' => 'setting',
      'ttl' => 3600,
      'auto_clear' => true,
    ),
    'driver' => 'database',
    'database' => 
    array (
      'connection' => NULL,
      'table' => 'settings',
      'key' => 'key',
      'value' => 'value',
    ),
    'json' => 
    array (
      'path' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage/settings.json',
    ),
    'override' => 
    array (
    ),
    'fallback' => 
    array (
    ),
    'required_extra_columns' => 
    array (
    ),
    'encrypted_keys' => 
    array (
    ),
  ),
  'sweetalert' => 
  array (
    'cdn' => NULL,
    'alwaysLoadJS' => false,
    'neverLoadJS' => false,
    'timer' => 5000,
    'width' => '32rem',
    'height_auto' => true,
    'padding' => '1.25rem',
    'animation' => 
    array (
      'enable' => false,
    ),
    'animatecss' => 'https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css',
    'show_confirm_button' => true,
    'show_close_button' => false,
    'toast_position' => 'top-end',
    'timer_progress_bar' => false,
    'middleware' => 
    array (
      'autoClose' => false,
      'toast_position' => 'top-end',
      'toast_close_button' => true,
      'timer' => 6000,
      'auto_display_error_messages' => false,
    ),
    'customClass' => 
    array (
      'container' => NULL,
      'popup' => NULL,
      'header' => NULL,
      'title' => NULL,
      'closeButton' => NULL,
      'icon' => NULL,
      'image' => NULL,
      'content' => NULL,
      'input' => NULL,
      'actions' => NULL,
      'confirmButton' => NULL,
      'cancelButton' => NULL,
      'footer' => NULL,
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\resources\\views',
    ),
    'compiled' => 'C:\\xampp\\htdocs\\platform\\platform_new_Updates\\storage\\framework\\views',
  ),
  'flare' => 
  array (
    'key' => NULL,
    'reporting' => 
    array (
      'anonymize_ips' => true,
      'collect_git_information' => false,
      'report_queries' => true,
      'maximum_number_of_collected_queries' => 200,
      'report_query_bindings' => true,
      'report_view_data' => true,
      'grouping_type' => NULL,
      'report_logs' => true,
      'maximum_number_of_collected_logs' => 200,
      'censor_request_body_fields' => 
      array (
        0 => 'password',
      ),
    ),
    'send_logs_as_events' => true,
    'censor_request_body_fields' => 
    array (
      0 => 'password',
    ),
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'light',
    'enable_share_button' => true,
    'register_commands' => false,
    'ignored_solution_providers' => 
    array (
      0 => 'Facade\\Ignition\\SolutionProviders\\MissingPackageSolutionProvider',
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
  ),
  'laravel-log-reader' => 
  array (
    'api_route_path' => 'admin/api/log-reader',
    'view_route_path' => 'admin/log-reader',
    'admin_panel_path' => 'admin',
    'middleware' => 
    array (
      0 => 'web',
      1 => 'auth',
    ),
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'lfm-config' => 
  array (
    'use_package_routes' => true,
    'allow_private_folder' => true,
    'private_folder_name' => 'UniSharp\\LaravelFilemanager\\Handlers\\ConfigHandler',
    'allow_shared_folder' => true,
    'shared_folder_name' => 'shares',
    'folder_categories' => 
    array (
      'file' => 
      array (
        'folder_name' => 'files',
        'startup_view' => 'list',
        'max_size' => 50000,
        'thumb' => true,
        'thumb_width' => 80,
        'thumb_height' => 80,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
          4 => 'application/pdf',
          5 => 'text/plain',
        ),
      ),
      'image' => 
      array (
        'folder_name' => 'photos',
        'startup_view' => 'grid',
        'max_size' => 50000,
        'thumb' => true,
        'thumb_width' => 80,
        'thumb_height' => 80,
        'valid_mime' => 
        array (
          0 => 'image/jpeg',
          1 => 'image/pjpeg',
          2 => 'image/png',
          3 => 'image/gif',
        ),
      ),
    ),
    'paginator' => 
    array (
      'perPage' => 30,
    ),
    'disk' => 'public',
    'rename_file' => false,
    'rename_duplicates' => false,
    'alphanumeric_filename' => false,
    'alphanumeric_directory' => false,
    'should_validate_size' => false,
    'should_validate_mime' => true,
    'over_write_on_duplicate' => false,
    'item_columns' => 
    array (
      0 => 'name',
      1 => 'url',
      2 => 'time',
      3 => 'icon',
      4 => 'is_file',
      5 => 'is_image',
      6 => 'thumb_url',
    ),
    'should_create_thumbnails' => true,
    'thumb_folder_name' => 'thumbs',
    'raster_mimetypes' => 
    array (
      0 => 'image/jpeg',
      1 => 'image/pjpeg',
      2 => 'image/png',
    ),
    'thumb_img_width' => 200,
    'thumb_img_height' => 200,
    'file_type_array' => 
    array (
      'pdf' => 'Adobe Acrobat',
      'doc' => 'Microsoft Word',
      'docx' => 'Microsoft Word',
      'xls' => 'Microsoft Excel',
      'xlsx' => 'Microsoft Excel',
      'zip' => 'Archive',
      'gif' => 'GIF Image',
      'jpg' => 'JPEG Image',
      'jpeg' => 'JPEG Image',
      'png' => 'PNG Image',
      'ppt' => 'Microsoft PowerPoint',
      'pptx' => 'Microsoft PowerPoint',
    ),
    'php_ini_overrides' => 
    array (
      'memory_limit' => '256M',
    ),
  ),
  'active' => 
  array (
    'class' => 'active',
  ),
  'sluggable' => 
  array (
    'source' => NULL,
    'maxLength' => NULL,
    'maxLengthKeepWords' => true,
    'method' => NULL,
    'separator' => '-',
    'unique' => true,
    'uniqueSuffix' => NULL,
    'firstUniqueSuffix' => 2,
    'includeTrashed' => false,
    'reserved' => NULL,
    'onUpdate' => false,
    'slugEngineOptions' => 
    array (
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 94,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
